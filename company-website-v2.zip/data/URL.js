export const URL = [
    {uri: ['/', '#home'], name: 'home'},
    {uri: ['/about', '#about'], name: 'about us'},
    {uri: ['/services', '#services'], name: 'services'},
    {uri: ['/book-appointment'], name: 'contact us'},
    {uri: ['/join'], name: 'join'},
]