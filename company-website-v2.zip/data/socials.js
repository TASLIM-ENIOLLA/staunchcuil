export default [
	{
		id: 1,
		name: 'facebook',
		icon: 'facebook'
	},
	{
		id: 2,
		name: 'github',
		icon: 'github'
	},
	{
		id: 3,
		name: 'pinterest',
		icon: 'pinterest'
	},
	{
		id: 4,
		name: 'twitter',
		icon: 'twitter'
	},
	{
		id: 5,
		name: 'google',
		icon: 'google'
	},
	{
		id: 6,
		name: 'linkedin',
		icon: 'linkedin'
	},
]